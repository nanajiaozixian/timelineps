<html>
	<form name="input" action="timeline.php" method="post">
	Username: <input type="text" name="user" value=""><br>
	Password: <input type="password" name="password"><br>

	
	<input type="submit" value="Submit">
</form> 
</html>
