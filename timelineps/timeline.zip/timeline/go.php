hello, you are survive.

<p><input type=text name=url></input>
	<input type="submit" value="Submit">